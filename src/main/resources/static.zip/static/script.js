function openLoginPage() {
    window.open("./login/login.html", "_self", "", true);
}